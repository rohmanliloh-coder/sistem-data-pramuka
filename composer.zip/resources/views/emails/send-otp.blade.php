<h2>Kode OTP Verifikasi Anda</h2>

<p>Berikut kode OTP Anda:</p>

<h1 style="font-size: 32px; font-weight: bold;">{{ $otp }}</h1>

<p>Kode ini berlaku selama 10 menit.</p>

<p>Terima kasih.</p>
